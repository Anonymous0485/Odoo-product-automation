import logging
import json
from odoo import http
from odoo.http import request
from odoo.exceptions import ValidationError, AccessError

logger = logging.getLogger(__name__)

class ProductAutomationController(http.Controller):
    @http.route('/product/create', type='json', auth='user', methods=['POST'], csrf=False)
    def create_product(self, **kwargs):
        try:
            logger.info("Received product creation request: %s", request.httprequest.data)
            data = json.loads(request.httprequest.data)

            # Validate required fields
            required_fields = ['name', 'list_price']
            for field in required_fields:
                if not data.get(field):
                    logger.error("Missing required field: %s", field)
                    return {
                        'status': 'error',
                        'message': f'Missing required field: {field}'
                    }

            # Find the Unit of Measure (UoM) ID for "Unit(s)"
            uom_unit = request.env.ref('uom.product_uom_unit')
            if not uom_unit:
                logger.error("Unit of Measure 'Unit(s)' not found")
                return {
                    'status': 'error',
                    'message': "Unit of Measure 'Unit(s)' not found"
                }
            logger.info("Found Unit of Measure 'Unit(s)' with ID: %s", uom_unit.id)

            # Assuming at least one product category exists (no fallback creation)
            product_category = request.env['product.category'].sudo().search([], limit=1)
            if not product_category:
                return {
                    'status': 'error',
                    'message': "No product categories found. Please ensure at least one category exists or create one manually."
                }

            # Find or create the "On Sale Now" eCommerce category for public_categ_ids
            ecommerce_category = request.env['product.public.category'].sudo().search([('name', '=', 'On Sale Now')], limit=1)
            if not ecommerce_category:
                logger.warning("eCommerce category 'On Sale Now' not found, attempting to create it")
                try:
                    ecommerce_category = request.env['product.public.category'].sudo().create({
                        'name': 'On Sale Now',
                        'parent_id': False,
                    })
                    logger.info("Created eCommerce category 'On Sale Now' with ID: %s", ecommerce_category.id)
                except Exception as e:
                    logger.error("Failed to create eCommerce category 'On Sale Now': %s", str(e))
                    return {
                        'status': 'error',
                        'message': f"Failed to create eCommerce category 'On Sale Now': {str(e)}. Please ensure the user has permissions to create eCommerce categories."
                    }
            else:
                logger.info("Using eCommerce category 'On Sale Now' with ID: %s", ecommerce_category.id)

            # Determine traceability based on price
            list_price = float(data.get('list_price'))
            tracking = 'serial' if list_price > 50 else 'none'

            # Prepare product data with default values and additional configurations
            product_data = {
                'name': data.get('name'),  
                'list_price': list_price,
                'description': data.get('name'),  
                'type': 'product',  
                'invoice_policy': 'delivery', 
                'uom_id': uom_unit.id, 
                'uom_po_id': uom_unit.id, 
                'standard_price': 0.00,  
                'categ_id': product_category.id, 
                'sale_ok': True, 
                'purchase_ok': True,  
                'taxes_id': [(6, 0, [])], 
                'default_code': data.get('default_code', False), 

                # Sales Tab: Set eCommerce category and sales description
                'public_categ_ids': [(6, 0, [ecommerce_category.id])],  
                'description_sale': data.get('name'),  

                # Purchase Tab: Set purchase description
                'description_purchase': data.get('name'),  

                # Inventory Tab: Set traceability and descriptions
                'tracking': tracking, 
                'description_picking': data.get('name'),  
                'description_pickingout': data.get('name'),  
                'description_pickingin': data.get('name'),  
            }

            logger.info("Product data to be created: %s", product_data)

            # Create the product
            product = request.env['product.product'].sudo().create(product_data)
            logger.info("Product created successfully: %s (ID: %s)", product.name, product.id)

            logger.info("Product Category after creation: %s (ID: %s)", product.categ_id.name, product.categ_id.id)
            logger.info("eCommerce Categories after creation: %s", product.public_categ_ids.mapped('name'))

            # Prepare the success response
            response_data = {
                'status': 'success',
                'message': 'Product created successfully',
                'product_id': product.id,
                'product_name': product.name,
            }

            return request.make_json_response(
                response_data,
                status=200,
                headers={
                    'Content-Type': 'application/json',
                    'Cache-Control': 'no-cache',
                }
            )

        except ValidationError as e:
            logger.error("Validation error: %s", str(e))
            return {'status': 'error', 'message': f'Validation error: {str(e)}'}
        except AccessError as e:
            logger.error("Access error: %s", str(e))
            return {'status': 'error', 'message': f'Access error: {str(e)}'}
        except Exception as e:
            logger.error("Unexpected error: %s", str(e))
            return {'status': 'error', 'message': f'Unexpected error: {str(e)}'}