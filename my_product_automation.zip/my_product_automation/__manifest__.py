{
    'name': "Product Automation",
    'version': '1.0',
    'depends': ['base', 'product'],  # Dependencies: base and product modules
    'author': "Netsec",
    'category': 'Tools',
    'description': """
    A module to automate product creation in Odoo via an API endpoint.
    Provides a /product/create endpoint to create products programmatically.
    """,
    'data': [],  # No views or data files for now
    'installable': True,
    'auto_install': True,
}